from collections import deque
import random
import numpy as np


class ReplayBuffer(object):

    def __init__(self, buffer_size):
        self.buffer_size = buffer_size
        self.num_experiences = 0
        self.buffer = deque()

    def get_batch(self, batch_size):
        # Randomly sample batch_size examples
        return random.sample(self.buffer, batch_size)

    def sample_batch(self, batch_size):
        # Randomly sample batch_size examples
        batch = random.sample(self.buffer, batch_size)

        s_batch = np.array([_[0] for _ in batch])

        a_batch = np.array([_[1] for _ in batch])

        r_batch = np.array([_[2] for _ in batch])

        t_batch = np.array([_[3] for _ in batch])

        s2_batch = np.array([_[4] for _ in batch])
        count_batch = np.array([_[5] for _ in batch])

        return s_batch, a_batch, r_batch, t_batch, s2_batch, count_batch

    def size(self):
        return self.num_experiences  # self.buffer_size

    def add(self, state, action, reward, done, new_state, count):
        experience = (state, action, reward, done, new_state, count)
        if self.num_experiences < self.buffer_size:
            self.buffer.append(experience)
            self.num_experiences += 1
        else:
            self.buffer.popleft()
            self.buffer.append(experience)

    def count(self):
        # if buffer is full, return buffer size
        # otherwise, return experience counter
        return self.num_experiences

    def erase(self):
        self.buffer = deque()
        self.num_experiences = 0
