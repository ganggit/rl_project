import pickle
import matplotlib.pyplot as plt
import collections

Data = collections.namedtuple("Data", ["steps", "reward"])
'''
# filename = "halfcheetah_with_w2w3"  # "ac_activelearning_bipedal.pickle"
filename = "/home/ganche/Downloads/TD/HalfCheetah-v2_0.pickle"
alldata = pickle.load(open(filename, "rb"))

print(alldata)
alldata[2]
plt.plot(alldata[2])
#plt.show()
'''
filename = "/home/ganche/Downloads/TD/HalfCheetah-v2_2.pickle" #HalfCheetah-v2_1.pickle"
data = pickle.load(open(filename, "rb"))
rewards = []
for item in data:
    rewards.append(item.reward)

plt.plot(rewards)
plt.show()

filename = "/home/ganche/Downloads/TD/HalfCheetah-v2_0.pickle" #HalfCheetah-v2_1.pickle"
data = pickle.load(open(filename, "rb"))
rewards = []
for item in data:
    rewards.append(item.reward)

plt.plot(rewards)
plt.show()

filename = "/home/ganche/Downloads/TD/HalfCheetah-v2DDPG_1.pickle" #HalfCheetah-v2_1.pickle"
data = pickle.load(open(filename, "rb"))
rewards = []
for item in data:
    rewards.append(item.reward)

plt.plot(rewards)
plt.show()

# good result from my approach
filename ="HalfCheetah-v2_1+sz_all4_ave.pickle"#"HalfCheetah-v2_4.pickle" #"HalfCheetah-v2_2.pickle" # "HalfCheetah-v2_10.pickle"
alldata = pickle.load(open(filename, "rb"))
plt.plot(alldata[2])

plt.show()

alldata = pickle.load(
    open("half_cheetah_allmin.pickle", "rb"))
plt.plot(alldata[2])
plt.show()

filename = "halfcheetah_removew2w3_1e6.pickle" 
alldata = pickle.load(open(filename, "rb"))
plt.plot(alldata[2])

plt.show()
