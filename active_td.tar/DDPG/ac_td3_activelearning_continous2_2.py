# %matplotlib inline
# from lib import plotting
# from lib.envs.cliff_walking import CliffWalkingEnv
import gym
import itertools
import matplotlib
import numpy as np
import math
import sys
import tensorflow as tf

import collections
import gym
import pickle
import plotting
from replay_buffer2 import ReplayBuffer
import sklearn.pipeline
import sklearn.preprocessing
from sklearn.kernel_approximation import RBFSampler

if "../" not in sys.path:
    sys.path.append("../")

# matplotlib.style.use('ggplot')

env = gym.make('BipedalWalker-v2')
# env.seed(1)  # reproducible
# env = env.unwrapped
# model initialization
D = 24  # input dimensionality
C = 4  # class number
NUM_HIDDEN1 = 400
NUM_HIDDEN2 = 300
TAU2 = 250
MINIBATCH_SIZE = 100
BUFFER_SIZE = 100000


class PolicyEstimator:
    """
    Policy Function approximator.
    """

    def __init__(self, env, batch_size, learning_rate=0.001, tau=0.001):
        # state_dim = env.observation_space.shape[0]
        action_dim = env.action_space.shape[0]
        state_dim = env.observation_space.shape[0]
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        self.tau = tau

        self.state, self.action, self.scaled_action = self.create_actor(env)
        self.network_params = tf.trainable_variables()

        self.target_state, self.target_action, self.target_scaled_action = self.create_actor(
            env)
        self.target_network_params = tf.trainable_variables()[
            len(self.network_params):]

        # Op for periodically updating target network with online network weights
        self.update_target_network_params = \
            [self.target_network_params[i].assign(tf.multiply(self.network_params[i], self.tau) +
                                                  tf.multiply(self.target_network_params[i], 1. - self.tau))
             for i in range(len(self.target_network_params))]

        # This gradient will be provided by the critic network
        self.action_gradient = tf.placeholder(
            tf.float32, [None, self.action_dim])

        # Combine the gradients here
        self.unnormalized_actor_gradients = tf.gradients(
            self.scaled_action, self.network_params, -self.action_gradient)

        self.actor_gradients = list(map(lambda x: tf.div(
            x, self.batch_size), self.unnormalized_actor_gradients))
        # Optimization Op by applying gradient, variable pairs
        self.optimize = tf.train.AdamOptimizer(self.learning_rate). \
            apply_gradients(zip(self.actor_gradients, self.network_params))

        self.num_trainable_vars = len(
            self.network_params) + len(self.target_network_params)

    def create_actor(self, env):
        state = tf.placeholder(
            tf.float32, [None, self.state_dim], "state")
        # This is just table lookup estimator
        xx = tf.contrib.layers.fully_connected(
            inputs=state,
            num_outputs=NUM_HIDDEN1,
            activation_fn=tf.nn.relu,
            weights_initializer=tf.uniform_unit_scaling_initializer(-0.05, 0.05))
        x = tf.contrib.layers.fully_connected(
            inputs=xx,
            num_outputs=NUM_HIDDEN2,
            activation_fn=tf.nn.relu,
            weights_initializer=tf.uniform_unit_scaling_initializer(-0.05, 0.05))
        mu = tf.contrib.layers.fully_connected(
            inputs=x,
            num_outputs=env.action_space.shape[0],
            activation_fn=tf.nn.tanh,
            weights_initializer=tf.uniform_unit_scaling_initializer(-0.05, 0.05))

        action_max = max(env.action_space.high)
        action = tf.clip_by_value(
            mu, env.action_space.low,  env.action_space.high)
        scaled_action = mu*action_max
        return state, action, scaled_action

    def predict(self, state, sess=None):
        sess = sess or tf.get_default_session()
        return sess.run(self.scaled_action, {self.state: state})

    def update(self, state, action_gradient, sess=None):
        sess = sess or tf.get_default_session()
        feed_dict = {self.state: state,
                     self.action_gradient: action_gradient}
        sess.run(self.optimize, feed_dict)

    def predict_target(self, state, sess=None):
        sess = sess or tf.get_default_session()
        return sess.run(self.target_scaled_action, feed_dict={
            self.target_state: state
        })

    def update_target_network(self, sess=None):
        sess = sess or tf.get_default_session()
        sess.run(self.update_target_network_params)

    def get_num_trainable_vars(self):
        return self.num_trainable_vars


class ValueEstimator():
    """
    Value Function approximator.
    """

    def __init__(self, env, learning_rate=0.005, tau=0.001, num_actor_vars=1):
        state_dim = env.observation_space.shape[0]
        action_dim = env.action_space.shape[0]
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.learning_rate = learning_rate
        self.tau = tau
        # Create the critic network
        self.state, self.action, self.q1, self.q2 = self.create_critic()
        self.network_params = tf.trainable_variables()[num_actor_vars:]

        # Target Network
        self.target_state,  self.target_action, self.target_q1, self.target_q2 = self.create_critic()

        self.target_network_params = tf.trainable_variables(
        )[(len(self.network_params) + num_actor_vars):]

        # Op for periodically updating target network with online network weights with regularization
        self.update_target_network_params = [self.target_network_params[i].assign(
            tf.multiply(self.network_params[i], self.tau) + tf.multiply(self.target_network_params[i], 1. - self.tau))
            for i in range(len(self.target_network_params))]

        self.target = tf.placeholder(
            tf.float32, [None, 1], name="target_name")
        # self.loss = tf.reduce_mean(tf.squared_difference(
        #    self.value_estimate, self.target))
        self.loss = 0.5*tf.reduce_mean(
            tf.square(tf.subtract(self.target, self.q1))) + 0.5*tf.reduce_mean(
            tf.square(tf.subtract(self.target, self.q2)))
        # self.loss = tf.nn.l2_loss(
        #   self.target - self.q1) + tf.nn.l2_loss(self.target - self.q2)
        self.optimizer = tf.train.AdamOptimizer(
            learning_rate=self.learning_rate)
        self.train_op = self.optimizer.minimize(
            self.loss, global_step=tf.contrib.framework.get_global_step())

        # Get the gradient of the net w.r.t. the action
        self.action_grads = tf.gradients(self.q1, self.action)

        grads_and_vars = self.optimizer.compute_gradients(
            self.loss, self.action)
        self.action_grads1 = grads_and_vars[0] 

        self.action_grads2 = tf.gradients(0.5*tf.reduce_mean(
            tf.square(tf.subtract(self.target, self.q1))), self.action)#, stop_gradients=[self.state,self.action])

    def create_critic(self):
        state = tf.placeholder(
            tf.float32, [None, self.state_dim], name="stateph")
        action = tf.placeholder(
            tf.float32, [None, self.action_dim], name="actionph")

        # This is just table lookup estimator
        xx = tf.contrib.layers.fully_connected(
            inputs=tf.concat([state, action], 1),
            num_outputs=NUM_HIDDEN1,
            activation_fn=tf.nn.relu,
            weights_initializer=tf.random_normal_initializer(0, 0.01))
        # This is just table lookup estimator
        x = tf.contrib.layers.fully_connected(
            inputs=xx,
            num_outputs=NUM_HIDDEN2,
            activation_fn=tf.nn.relu,
            weights_initializer=tf.random_normal_initializer(0, 0.01))
        q1 = tf.contrib.layers.fully_connected(
            inputs=x,
            num_outputs=1,
            activation_fn=None,
            weights_initializer=tf.random_normal_initializer(0, 0.01))

        # This is just table lookup estimator
        xx2 = tf.contrib.layers.fully_connected(
            inputs=tf.concat([state, action], 1),
            num_outputs=NUM_HIDDEN1,
            activation_fn=tf.nn.relu,
            weights_initializer=tf.random_normal_initializer(0, 0.01))
        # This is just table lookup estimator
        x2 = tf.contrib.layers.fully_connected(
            inputs=xx2,
            num_outputs=NUM_HIDDEN2,
            activation_fn=tf.nn.relu,
            weights_initializer=tf.random_normal_initializer(0, 0.01))
        q2 = tf.contrib.layers.fully_connected(
            inputs=x2,
            num_outputs=1,
            activation_fn=None,
            weights_initializer=tf.random_normal_initializer(0, 0.01))
        return state, action, q1, q2

    def predict(self, state, action, sess=None):
        sess = sess or tf.get_default_session()
        # state = featurize_state(state)
        return sess.run([self.q1, self.q2], {self.state: state, self.action: action})

    def update(self, state, action, target, sess=None):
        sess = sess or tf.get_default_session()
        # state = featurize_state(state)
        feed_dict = {self.state: state,
                     self.action: action, self.target: target}
        _, loss = sess.run([self.train_op, self.loss], feed_dict)
        return loss

    def action_gradients(self, inputs, actions, target, sess=None):
        sess = sess or tf.get_default_session()
        return sess.run(self.action_grads, feed_dict={
            self.state: inputs,
            self.action: actions,
            self.target: target
        })

    def get_action_grads(self, state, action, sess=None):
        sess = sess or tf.get_default_session()
        return sess.run(self.action_grads, feed_dict={
            self.state: state,
            self.action: action
        })

    def predict_target(self, state, action, sess=None):
        sess = sess or tf.get_default_session()
        # state = featurize_state(state)
        q1, q2 = sess.run([self.target_q1, self.target_q2], feed_dict={
            self.target_state: state,
            self.target_action: action
        })
        return q1, q2

    def update_target_network(self, sess=None):
        sess = sess or tf.get_default_session()
        sess.run(self.update_target_network_params)


def zoomUpdate(estimator_value, estimator_policy, subepisode, discount_factor, mix):

    num = len(subepisode)
    objval = np.zeros(num)
    tdiff = np.zeros(num)
    targets = np.zeros(num)
    diff = []
    esum = []

    for i in range(num):
        trans = subepisode[i]
        v1, v2 = estimator_value.predict(trans[0], trans[1])
        value = np.minimum(v1, v2)
        v1, v2 = estimator_value.predict_target(
            trans[3], estimator_policy.predict_target(trans[3]))
        value_next = np.minimum(v1, v2)
        # if trans[4]:
        #    value_next = 0
        rc = value - discount_factor*value_next
        re = trans[2]
        diff.append((re-rc)**2)
        prob = trans[5]
        ssq = np.sum(prob[0]**2, axis=0)
        esum.append(prob)
        objval[i] = (re-rc)**2 + mix*(ssq)  # measure the uncertainty
        target = re + discount_factor*value_next
        td = target - value
        tdiff[i] = td
        targets[i] = target
    return objval, tdiff, targets


def computeReward(rewards, discount):
    val = 0
    factor = 1
    for r in rewards:
        r = r * factor
        val = val + r
        factor = factor * discount
    return val


def entropy(prob):
    e = 0

    for p in prob:
        e = e - p*math.log(p, 2)
    '''
    try:
        for p in prob:
            e = e - p*math.log(p, 2)
    except:
        print("except happen: {}".format(prob))
    '''
    return e


class OrnsteinUhlenbeckActionNoise:

    def __init__(self, mu, sigma=0.3, theta=.15, dt=1e-2, x0=None):
        self.theta = theta
        self.mu = mu
        self.sigma = sigma
        self.dt = dt
        self.x0 = x0
        self.reset()

    def __call__(self):
        x = self.x_prev + self.theta * (self.mu - self.x_prev) * self.dt + \
            self.sigma * np.sqrt(self.dt) * \
            np.random.normal(size=self.mu.shape)
        self.x_prev = x
        return x

    def reset(self):

        self.x_prev = self.x0 if self.x0 is not None else np.zeros_like(
            self.mu)

    def __repr__(self):

        return 'OrnsteinUhlenbeckActionNoise(mu={}, sigma={})'.format(self.mu, self.sigma)


def actor_critic(env, estimator_policy, estimator_value, actor_noise, num_episodes, steps=[1, 1, 1, 1], discount_factor=1.0):
    """
    Actor Critic Algorithm. Optimizes the policy
    function approximator using policy gradient.

    Args:
        env: OpenAI environment.
        estimator_policy: Policy Function to be optimized
        estimator_value: Value function approximator, used as a critic
        num_episodes: Number of episodes to run for
        discount_factor: Time-discount factor

    Returns:
        An EpisodeStats object with two numpy arrays for episode_lengths and episode_rewards.
    """

    # Keeps track of useful statistics
    stats = plotting.EpisodeStats(
        episode_lengths=np.zeros(num_episodes),
        episode_rewards=np.zeros(num_episodes))

    Transition = collections.namedtuple(
        "Transition", ["state", "action", "reward", "next_state", "done", "probs", "index"])

    StateInfo = collections.namedtuple(
        "Transition", ["state", "action", "index",  "next_state"])

    # Initialize replay memory
    replay_buffer = ReplayBuffer(BUFFER_SIZE)

    loops = int(num_episodes/len(steps))
    index = 0
    step = 10
    total_timesteps = 0
    start_timesteps =  1000 # 10000
    for i_episode in range(num_episodes):
        # Reset the environment and pick the fisrst action
        state = env.reset()
        state = np.reshape(state, (1, env.observation_space.shape[0]))
        next_state = state  # initialization
        action = 0
        episode = []

        if((i_episode) % loops == 0):
            # get the step
            step = steps[index]
            print("the current index and stepsize  is %d and %d \n" %
                  (index, steps[index]))
            index = index+1

        rewardList = []
        replay = []
        gid = 0
        # One step in the environment
        noise_clip = 0.5
        for t in itertools.count():
            count = 1
            R = []
            subepisode = []
            env.render()
            while(True):
                local_state = next_state
                if total_timesteps < start_timesteps:
                    next_action = env.action_space.sample()
                    next_action = np.reshape(
                        next_action, (1, env.action_space.shape[0]))
                else:
                    # Take a step
                    noise = np.random.normal(
                        0, 0.2, size=env.action_space.shape[0])
                    noise = np.clip(noise, -noise_clip, noise_clip)
                    action_probs = estimator_policy.predict(
                        local_state) + noise
                    action_probs = np.clip(
                        action_probs, env.action_space.low, env.action_space.high)
                    # print(action_probs)
                    next_action = action_probs  # np.reshape(action_probs, -1)
                grads = estimator_value.get_action_grads(
                    local_state, next_action)
                try:
                    next_state, reward, done, _ = env.step(next_action[0])
                except:
                    stop = 1

                # reward /= 10  # see what is happen
                next_state = np.reshape(
                    next_state, (1, env.observation_space.shape[0]))
                if(count == 1):
                    action = next_action
                    replay.append(StateInfo(
                        state=local_state, action=next_action, index=gid, next_state=next_state))
                    # add it to the replay buffer
                    #replay_buffer.add(np.reshape(local_state, (estimator_policy.state_dim,)), next_action, reward,
                    #                  done, np.reshape(next_state, (estimator_policy.state_dim,)), 1)
                # if done and i_episode<400:
                #   reward = -20
                R.append(reward)
                rewardList.append(reward)
                # save the data
                subepisode.append(Transition(
                    state=local_state, action=next_action, reward=reward, next_state=next_state, done=done, probs=grads[0], index=gid))

                # train the model by sampling from batch
                if replay_buffer.size() > MINIBATCH_SIZE:
                    s_batch, a_batch, r_batch, t_batch, s2_batch, intervals = replay_buffer.sample_batch(
                        MINIBATCH_SIZE)

                    # Calculate TD Target
                    noise = np.clip(actor_noise(), -noise_clip, noise_clip)
                    a2 = estimator_policy.predict_target(s2_batch) + noise
                    a2 = np.clip(a2, env.action_space.low, 
                                 env.action_space.high)
                    tq1, tq2 = estimator_value.predict_target(s2_batch, a2)
                    # print("\rq1 and q2: {}, {}".format(tq1[0:2,0], tq2[0:2,0]))
                    value_next = np.minimum(tq1, tq2)

                    #if i_episode>1000:
                    #    value_next = np.minimum(tq1, tq2)
                    '''
                    a1 = estimator_policy.predict(s_batch) + noise
                    a1 = np.clip(a1, env.action_space.low, 
                                 env.action_space.high)
                    tq1, tq2 = estimator_value.predict_target(s_batch, a1)
                    value_next2 = np.maximum(tq1, tq2)
                    value_next = np.minimum(value_next, value_next2)
                    '''
                    td_target = np.zeros(MINIBATCH_SIZE)
                    for k in range(MINIBATCH_SIZE):
                        if t_batch[k]:
                            td_target[k] = r_batch[k]
                        else:
                            td_target[k] = r_batch[k] + \
                                (discount_factor**intervals[k]) * value_next[k]

                    grads = estimator_value.action_gradients(
                            s_batch, np.reshape(a_batch, (-1, estimator_value.action_dim)), np.reshape(td_target, (-1, 1)))
                    # Update the value estimator
                    estimator_value.update(
                        s_batch, np.reshape(a_batch, (-1, estimator_value.action_dim)), np.reshape(td_target, (-1, 1)))

                    # Update the policy estimator
                    estimator_policy.update(s_batch, np.reshape(
                            grads[0], (-1, estimator_value.action_dim)))
                    if(count%2==0):    
                        estimator_policy.update_target_network()
                    estimator_value.update_target_network()

                if done or count >= step:
                    break    
                gid = gid + 1
                count = count + 1

            totalR = computeReward(R, discount_factor)
            # the out loop to keep the state
            # episode.append(Transition(
            #    state=state, action=action, reward=totalR, next_state=next_state, done=done, probs=action_probs[0], index=count))
            idx = 0
            if(step > 1 and len(subepisode) > 0):
                tmp, td_error, targets = zoomUpdate(
                    estimator_value, estimator_policy, subepisode, discount_factor, 2.5)
                idx = np.argmax(tmp)
                noise = np.clip(actor_noise(), -noise_clip, noise_clip)
                next_a = estimator_policy.predict_target(
                    subepisode[idx][3]) + noise
                tq1, tq2 = estimator_value.predict_target(
                    subepisode[idx][3], next_a)
                target = np.minimum(tq1, tq2)
                if subepisode[idx][4]:
                    target = subepisode[idx][2]
                else:
                    target = subepisode[idx][2] + discount_factor*(target)
                # cq1, cq2 = estimator_value.predict(subepisode[idx][0], subepisode[idx][1])
                
                grads = estimator_value.get_action_grads(subepisode[idx][0], subepisode[idx][1])
                estimator_value.update(subepisode[idx][0], subepisode[idx][1], np.reshape(target, (-1, 1)))

                estimator_policy.update(subepisode[idx][0], grads[0])

                estimator_value.update_target_network()
                estimator_policy.update_target_network()
                # Keep track of the transition
                
                # Keep track of the transition
                subid = len(subepisode)-1
                if idx != 0 and idx!=subid:
                    replay.append(StateInfo(
                        state=subepisode[idx][0], action=subepisode[idx][1], index=subepisode[idx][6], next_state=subepisode[idx][3]))

                    replay_buffer.add(np.reshape(subepisode[idx][0], (estimator_policy.state_dim,)), subepisode[idx][1], subepisode[idx][2],
                                  subepisode[idx][4], np.reshape(subepisode[idx][3], (estimator_policy.state_dim,)), 1)
            # Update statistics
            stats.episode_rewards[i_episode] += sum(R)
            stats.episode_lengths[i_episode] = gid
            '''
            # Calculate TD Target
            noise_clip = 0.5
            noise = np.clip(actor_noise(), -noise_clip, noise_clip)
            tq1, tq2 = estimator_value.predict_target(next_state, estimator_policy.predict_target(next_state)+noise)
            value_next = np.minimum(tq1[0], tq2[0])
            if done:
                value_next = 0
            td_target = totalR + (discount_factor**count) * value_next
            grads = estimator_value.action_gradients(state, action, np.reshape(td_target, (-1, 1)))
            # Update the value estimator
            estimator_value.update(
                state, action, np.reshape(td_target, (-1, 1)))
            # Update the policy estimator
            estimator_policy.update(state, grads[0])

            estimator_value.update_target_network()
            estimator_policy.update_target_network()
            '''

            # Print out which step we're on, useful for debugging.
            print("\rStep {} @ Episode {}/{} ({})".format(
                total_timesteps, i_episode + 1, num_episodes, stats.episode_rewards[i_episode - 1]), end="")

            if done or t > 10000:
                replay.append(StateInfo(
                    state=local_state, action=next_action, index=gid, next_state=next_state))
                replay_buffer.add(np.reshape(local_state, (estimator_policy.state_dim,)), next_action, reward,
                                  done, np.reshape(next_state, (estimator_policy.state_dim,)), 1)
                break

            state = next_state
            total_timesteps += 1
        if(step>1): 
            # for the replay buffer
            num = len(replay)
            for i in range(1, num):
                pre_state, pre_action, pre_id, _ = replay[i-1]
                state, action, cid, _ = replay[i] 
                # calculate discounted monte-carlo return
                future_reward = 0
                factor = 1
                for ii in range(pre_id, cid):
                    future_reward = future_reward + rewardList[ii]*factor
                    factor = factor*discount_factor

                replay_buffer.add(np.reshape(pre_state, (estimator_policy.state_dim,)), pre_action, future_reward,
                    False, np.reshape(state, (estimator_policy.state_dim,)), cid-pre_id)

    return stats


tf.reset_default_graph()

global_step = tf.Variable(0, name="global_step", trainable=False)
policy_estimator = PolicyEstimator(env,MINIBATCH_SIZE, 0.0001, 0.005)
value_estimator = ValueEstimator(
    env, 0.001, 0.005, policy_estimator.get_num_trainable_vars())

actor_noise = OrnsteinUhlenbeckActionNoise(
    mu=np.zeros(policy_estimator.action_dim))
steps = [6, 6, 4, 4]
with tf.Session() as sess:
    sess.run(tf.initialize_all_variables())
    # Note, due to randomness in the policy the number of episodes you need to learn a good
    # policy may vary. ~300 seemed to work well for me.
    policy_estimator.update_target_network()
    value_estimator.update_target_network()
    stats = actor_critic(env, policy_estimator,
                         value_estimator, actor_noise, 3000, steps, 0.99)

plotting.plot_episode_stats(stats, smoothing_window=10)
with open("ac_activelearning_bipedal.pickle", 'wb') as handle:
    pickle.dump([stats[0], stats[1], stats.episode_lengths,
                 stats.episode_rewards], handle)
