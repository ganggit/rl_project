# %matplotlib inline
# from lib import plotting
# from lib.envs.cliff_walking import CliffWalkingEnv
import gym
import itertools
import matplotlib
import numpy as np
import math
import tensorflow as tf
import sys
import os
import argparse
import collections
import gym
import pickle
import plotting
from replay_buffer3 import ReplayBuffer
import sklearn.pipeline
import sklearn.preprocessing
from sklearn.kernel_approximation import RBFSampler

import random
import torch
import TD3_active4 as TD3


if "../" not in sys.path:
    sys.path.append("../")


def zoomUpdate(policy, subepisode, discount_factor, mix):

    num = len(subepisode)
    objval = np.zeros(num)
    tdiff = np.zeros(num)
    targets = np.zeros(num)
    diff = []
    esum = []

    for i in range(num):
        trans = subepisode[i]

        state = torch.FloatTensor(trans[0]).to(device)
        action = torch.FloatTensor(trans[1]).to(device)
        next_state = torch.FloatTensor(trans[3]).to(device)

        v1, v2 = policy.critic_target(state, action)
        value = np.minimum(v1.detach(), v2.detach())
        v1, v2 = policy.critic_target(
            next_state, policy.actor_target(next_state))
        value_next = np.minimum(v1.detach(), v2.detach())
        # if trans[4]:
        #    value_next = 0
        rc = value - discount_factor*value_next
        re = trans[2]
        diff.append((re-rc)**2)
        prob = trans[5]
        ssq = np.sum(prob**2, axis=0)
        esum.append(prob)
        objval[i] = (re-rc)**2 + mix*(ssq)  # measure the uncertainty
        target = re + discount_factor*value_next
        td = target - value
        tdiff[i] = td
        targets[i] = target
    return objval, tdiff, targets


def computeReward(rewards, discount):
    val = 0
    factor = 1
    for r in rewards:
        r = r * factor
        val = val + r
        factor = factor * discount
    return val


def entropy(prob):
    e = 0

    for p in prob:
        e = e - p*math.log(p, 2)
    '''
    try:
        for p in prob:
            e = e - p*math.log(p, 2)
    except:
        print("except happen: {}".format(prob))
    '''
    return e


class OrnsteinUhlenbeckActionNoise:

    def __init__(self, mu, sigma=0.3, theta=.15, dt=1e-2, x0=None):
        self.theta = theta
        self.mu = mu
        self.sigma = sigma
        self.dt = dt
        self.x0 = x0
        self.reset()

    def __call__(self):
        x = self.x_prev + self.theta * (self.mu - self.x_prev) * self.dt + \
            self.sigma * np.sqrt(self.dt) * \
            np.random.normal(size=self.mu.shape)
        self.x_prev = x
        return x

    def reset(self):

        self.x_prev = self.x0 if self.x0 is not None else np.zeros_like(
            self.mu)

    def __repr__(self):

        return 'OrnsteinUhlenbeckActionNoise(mu={}, sigma={})'.format(self.mu, self.sigma)


def actor_critic(env, policy, actor_noise, num_episodes, steps=[1, 1, 1, 1], discount_factor=1.0):

    # Keeps track of useful statistics
    stats = plotting.EpisodeStats(
        episode_lengths=np.zeros(num_episodes),
        sample_steps=np.zeros(num_episodes),
        episode_rewards=np.zeros(num_episodes))

    Transition = collections.namedtuple(
        "Transition", ["state", "action", "reward", "next_state", "done", "probs", "index"])

    StateInfo = collections.namedtuple(
        "Transition", ["state", "action", "index",  "next_state", "done"])

    # Initialize replay memory
    replay_buffer = ReplayBuffer(BUFFER_SIZE)

    loops = int(num_episodes/len(steps))
    index = 0
    step = 10
    total_timesteps = 0
    start_timesteps = 1e4  # 10000
    for i_episode in range(num_episodes):
        # Reset the environment and pick the fisrst action
        state = env.reset()
        state = np.reshape(state, (1, env.observation_space.shape[0]))
        next_state = state  # initialization
        action = 0
        episode = []

        if((i_episode) % loops == 0):
            # get the step
            step = steps[index]
            print("the current index and stepsize  is %d and %d \n" %
                  (index, steps[index]))
            index = index+1

        rewardList = []
        replay = []
        gid = 0
        # One step in the environment
        noise_clip = 0.5
        for t in itertools.count():
            count = 1
            R = []
            subepisode = []
            # env.render()
            while(True):
                local_state = next_state
                if total_timesteps < start_timesteps:
                    next_action = env.action_space.sample()
                    next_action = np.reshape(
                        next_action, (1, env.action_space.shape[0]))
                else:
                    # Take a step
                    noise = np.random.normal(
                        0, 0.1, size=env.action_space.shape[0])
                    # noise = np.clip(noise, -noise_clip, noise_clip)
                    # action_probs = policy.actor(torch.FloatTensor(
                    #     local_state).to(device)).detach().numpy() + noise
                    action_probs = policy.actor(torch.FloatTensor(
                        local_state).to(device)).detach().cpu().numpy() + noise
                    action_probs = np.clip(
                        action_probs, env.action_space.low, env.action_space.high)
                    # print(action_probs)
                    next_action = action_probs  # np.reshape(action_probs, -1)
                # grads = estimator_value.get_action_grads(
                #    local_state, next_action)
                try:
                    next_state, reward, done, _ = env.step(next_action[0])
                except:
                    stop = 1

                # reward /= 10  # see what is happen
                next_state = np.reshape(
                    next_state, (1, env.observation_space.shape[0]))
                if(count == 1):
                    replay.append(StateInfo(
                        state=local_state, action=next_action, index=gid, next_state=next_state, done=done))

                R.append(reward)
                rewardList.append(reward)
                # save the data
                subepisode.append(Transition(
                    state=local_state, action=next_action, reward=reward, next_state=next_state, done=done, probs=0, index=gid))

                if done or count >= step:
                    break  # break the inner loop
                gid = gid + 1
                count = count + 1

            totalR = computeReward(R, discount_factor)
            # the out loop to keep the state
            # episode.append(Transition(
            #    state=state, action=action, reward=totalR, next_state=next_state, done=done, probs=action_probs[0], index=count))
            idx = 0
            if(step > 1 and len(subepisode) > 0):
                tmp, td_error, targets = zoomUpdate(
                    policy, subepisode, discount_factor, 2.5)
                idx = np.argmax(tmp) 
                subid = len(subepisode)-1
                if idx==0 and subid>0:
                    idx = random.randint(1, subid) #random.sample(range(1, len(subepisode)), 1)
                # Keep track of the transition
                if idx != 0 and not done:
                    replay.append(StateInfo(
                        state=subepisode[idx][0], action=subepisode[idx][1], index=subepisode[idx][6], next_state=subepisode[idx][3], done=subepisode[idx][4]))
            
            # Update statistics
            stats.episode_rewards[i_episode] += sum(R)
            stats.episode_lengths[i_episode] = gid
            stats.sample_steps[i_episode] = total_timesteps
            # Print out which step we're on, useful for debugging.
            print("\rStep {} @ Episode {}/{} ({})".format(
                total_timesteps, i_episode + 1, num_episodes, stats.episode_rewards[i_episode - 1]), end="")

            if done:
                replay.append(StateInfo(
                    state=local_state, action=next_action, index=gid, next_state=next_state, done=done))
                break
            # update the old value    
            # action = next_action
            state = next_state
            total_timesteps += 1
            gid = gid + 1
        if(step > 1):
            # for the replay buffer
            num = len(replay)
            for i in range(1, num):
                pre_state, pre_action, pre_id, next_state, done = replay[i-1]
                nn_state, _, cid, nnn_state, nn_done = replay[i]
                if pre_id == cid:
                    continue  # skip the endding case
                # calculate discounted monte-carlo return
                curr_reward = rewardList[pre_id]
                '''
                replay_buffer.add(np.reshape(pre_state, (policy.state_dim,)), np.reshape(pre_action, (-1, policy.action_dim)), curr_reward,
                    False, np.reshape(next_state, (policy.state_dim,)), 1, 
                    np.reshape(next_state, (policy.state_dim,)), curr_reward, False, 1, 
                    np.reshape(next_state, (policy.state_dim,)), curr_reward, False, 1)
                '''
                future_reward = 0
                factor = 1
                for ii in range(pre_id, cid):
                    future_reward = future_reward + rewardList[ii]*factor
                    factor = factor*discount_factor
                '''
                # for enhancement in the learning
                replay_buffer.add(np.reshape(pre_state, (policy.state_dim,)), np.reshape(pre_action, (-1, policy.action_dim)), future_reward,
                    False, np.reshape(nn_state, (policy.state_dim,)), cid-pre_id, 
                    np.reshape(nn_state, (policy.state_dim,)), future_reward, False, cid-pre_id, 
                    np.reshape(nn_state, (policy.state_dim,)), future_reward, False, cid-pre_id)

                '''
                nnn_reward = future_reward + factor*rewardList[cid]
                replay_buffer.add(np.reshape(pre_state, (policy.state_dim,)), np.reshape(pre_action, (-1, policy.action_dim)), curr_reward,
                                  False, np.reshape(next_state, (policy.state_dim,)), 1, 
                                  np.reshape(nn_state, (policy.state_dim,)), future_reward, False, cid-pre_id, 
                                  np.reshape(nnn_state, (policy.state_dim,)), nnn_reward, nn_done, cid-pre_id+1)
            
          
            # the end of the episode
            pre_state, pre_action, pre_id, next_state, done = replay[num-1]  
            future_reward = rewardList[pre_id]  
            if(done):
                replay_buffer.add(np.reshape(pre_state, (policy.state_dim,)), np.reshape(pre_action, (-1, policy.action_dim)), future_reward,
                    True, np.reshape(next_state, (policy.state_dim,)), 1, 
                    np.reshape(next_state, (policy.state_dim,)), future_reward, True, 1, 
                    np.reshape(next_state, (policy.state_dim,)), future_reward, True, 1)
             
        # train the model by sampling from batch
        if replay_buffer.size() > MINIBATCH_SIZE:
            tau = 0.005
            policy_noise = 0.2
            noise_clip = 0.5
            policy_freq = 2
            policy.train(replay_buffer, len(rewardList), MINIBATCH_SIZE, discount_factor,
                         tau, policy_noise, noise_clip, policy_freq)

    return stats


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--policy_name", default="TD3")  # Policy name
    # parser.add_argument("--env_name", default="HalfCheetah-v1")  # OpenAI gym environment name
    # OpenAI gym environment name
    parser.add_argument("--env_name", default="BipedalWalker-v2")

    # Sets Gym, PyTorch and Numpy seeds
    parser.add_argument("--seed", default=0, type=int)
    parser.add_argument("--start_timesteps", default=1e4,
                        type=int)  # How many time steps purely random policy is run for
    # How often (time steps) we evaluate
    parser.add_argument("--eval_freq", default=5e3, type=float)
    # Max time steps to run environment for
    parser.add_argument("--max_timesteps", default=1e6, type=float)
    # Whether or not models are saved
    parser.add_argument("--save_models", action="store_true")
    # Std of Gaussian exploration noise
    parser.add_argument("--expl_noise", default=0.1, type=float)
    # Batch size for both actor and critic
    parser.add_argument("--batch_size", default=100, type=int)
    parser.add_argument("--discount", default=0.99,
                        type=float)  # Discount factor
    # Target network update rate
    parser.add_argument("--tau", default=0.005, type=float)
    # Noise added to target policy during critic update
    parser.add_argument("--policy_noise", default=0.2, type=float)
    # Range to clip target policy noise
    parser.add_argument("--noise_clip", default=0.5, type=float)
    # Frequency of delayed policy updates
    parser.add_argument("--policy_freq", default=2, type=int)
    parser.add_argument('--saved_filename',
                        default='ac_call_td3_bipedal_pytorch.pickle', type=str)
    parser.add_argument('--gpu_id', default='2', type=str)
    # Frequency of delayed policy updates
    parser.add_argument("--num_episodes", default=2000, type=int)
    args = parser.parse_args()
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu_id
    env = gym.make(args.env_name)
    # print(torch.cuda.current_device())
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print('device = ', device)
    #device = torch.cuda.set_device(int(args.gpu_id) if torch.cuda.is_available() else "cpu")
    tf.reset_default_graph()
    # env.seed(1)  # reproducible
    # env = env.unwrapped
    # model initialization
    D = 24  # input dimensionality
    C = 4  # class number
    NUM_HIDDEN1 = 400
    NUM_HIDDEN2 = 300
    TAU2 = 250
    MINIBATCH_SIZE = 100
    BUFFER_SIZE = 100000

    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]
    max_action = float(env.action_space.high[0])

    policy = TD3.TD3(state_dim, action_dim, max_action)

    actor_noise = OrnsteinUhlenbeckActionNoise(mu=np.zeros(policy.action_dim))
    steps = [2, 4, 6, 6, 8]

    # learning the model
    stats = actor_critic(env, policy, actor_noise, 4000, steps, 0.99)

    plotting.plot_episode_stats(stats, smoothing_window=10)
    with open(args.saved_filename, 'wb') as handle:
        pickle.dump([stats.episode_lengths, stats.sample_steps,
                     stats.episode_rewards], handle)
